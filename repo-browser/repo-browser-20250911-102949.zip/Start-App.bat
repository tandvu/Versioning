@echo off
setlocal
set SERVE_CLIENT=1
set PORT=5055
pushd "%~dp0runtime\server"
node ..\server\dist\index.js
popd
endlocal